import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

//import {server} from '../../package.json'

@Injectable({
  providedIn: 'root'
})
export default class CategoryService 
{
  constructor(private http:HttpClient) { }

  public getCategory() : Observable<any>
  {
    return this.http.get(`localhost:8080/category/load`)
  }
  public saveCategory(data:any) : Observable<any>
  {
    return this.http.post(`localhost:8080/category/save`,data)
  }
  /* public deletePatient(pid:String) : Observable<any>
  {
    return this.http.delete(`${server}/patient/delete/${pid}`,{observe: 'response'})
  }

  public updatePatient(ob:any) : Observable<any>
  {
    return this.http.put(`${server}/patient/update`,ob)
  }

  public loadImage(imagePath:string) : Observable<any>
  {
    const formData = new FormData();
    formData.append("imagePath",imagePath);
    return this.http.post(`${server}/patient/getImage`,formData)
  } */
}